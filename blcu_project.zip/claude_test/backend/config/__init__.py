# Django project configuration package
